# M.I.F. - текстовой помощник для настройки Линукса! 

- На данный момент доступны 2 версии файлов, для рабочих окружений Gnome 3 и KDE Plasma

#

<b>О проекте</b>: [Плафон](https://vk.com/plafonlinux) - <i>молодой Линукс канал, который занимается популяризацией Manjaro и разбором других арч-зависимых дистрибутивов ... В первую очередь проект ориентирован на новичков в Линуксе, стараясь своими гайдами и наглядными пособиями облегчить переход обычного пользователя Windows на операционные системы с ядром Линукс.

Большое внимание будет уделено работе в Krita и видеомонтажу в DaVinci Risolve, для создания полноценной альтернативы, застоявшийся в своем сегменте чрезмерно дорогих и не работающих на Линуксе продуктов от компании Adobe.

На досуге, на канале можно поприсутствовать на игровых стримах на Линуксе и PS4, а также по их запуску и установке ... Распаковки разных гаджетов для личного использования и не только, конкурсы, авторские видео блоги и подкасты ...

Все это теперь объединено под крышей одного проекта PlaFon (Плафон) ...

Спасибо всем за поддержку и понимание! Мы стараемся не стоять на месте и развиваться в правильном направлении!
</i>

#

### Ищи нас в сети и присоединяйся к проекту! Вместе мы сила! Linux for simply Life!
  
#

<b>Паблик ВК</b>: [vk.com/plafonlinux](vk.com/plafonlinux)

<b>Канал</b>: [youtube.com/plafonlinux](youtube.com/plafonlinux)

<b>Новости</b>: [t.me/plafonlinux](t.me/plafonlinux)

<b>Чат</b>: [t.me/plafonlinuxchat](t.me/plafonlinuxchat)

<b>Instagram</b>: [instagram.com/plafonlinux](instagram.com/plafonlinux)

<b>Файлики M.I.F.</b>: [https://vk.com/plafonlinux?w=wall-151303502_5826](https://vk.com/plafonlinux?w=wall-151303502_5826)

<b>Помощь проекту</b>: [https://www.donationalerts.com/r/plafonlinux](https://www.donationalerts.com/r/plafonlinux)

#

<b>Личное железо автора проекта</b>:

<b>Основной ПК</b>: [https://vk.com/plafonlinux?w=wall-151303502_5817](https://vk.com/plafonlinux?w=wall-151303502_5817)


<b>Ноутбук</b>: [https://vk.com/plafonlinux?w=wall-151303502_5759](https://vk.com/plafonlinux?w=wall-151303502_5759)
#

###### Powered by @plafonlinux
